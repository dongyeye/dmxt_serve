package fzu.edu.dmxt.controller;

import fzu.edu.dmxt.pojo.Student;
import fzu.edu.dmxt.service.StudentService;
import fzu.edu.dmxt.util.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class StudentController {
    @Autowired
    private StudentService studentService;

    @RequestMapping("student")
    public String list(Model model, Page page){
        List<Student> st = studentService.list(page);
        int total = studentService.total();
        page.setTotal(total);
        model.addAttribute("st",st);
        model.addAttribute("page",page);
        return "admin/student";
    }
}
