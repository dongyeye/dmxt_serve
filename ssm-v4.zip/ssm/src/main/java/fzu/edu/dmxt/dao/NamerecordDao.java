package fzu.edu.dmxt.dao;

public interface NamerecordDao {
}
