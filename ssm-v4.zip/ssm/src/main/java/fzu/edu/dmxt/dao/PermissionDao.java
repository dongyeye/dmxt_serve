package fzu.edu.dmxt.dao;

import fzu.edu.dmxt.pojo.Permission;

public interface PermissionDao {
    Permission get(int per_id);
}
