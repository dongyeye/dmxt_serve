package fzu.edu.dmxt.dao;

import fzu.edu.dmxt.pojo.Role;

public interface RoleDao {
    Role get(int id);
}
