package fzu.edu.dmxt.pojo;

public class Account {


    private int id;
    private String account_number;
    private String login_credent;
    private int landing_type;
    private int role_id;
    private int S_T_id;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAccount_number() {
        return account_number;
    }

    public void setAccount_number(String account_number) {
        this.account_number = account_number;
    }

    public String getLogin_credent() {
        return login_credent;
    }

    public void setLogin_credent(String login_credent) {
        this.login_credent = login_credent;
    }

    public int getLanding_type() {
        return landing_type;
    }

    public void setLanding_type(int landing_type) {
        this.landing_type = landing_type;
    }

    public int getRole_id() {
        return role_id;
    }

    public void setRole_id(int role_id) {
        this.role_id = role_id;
    }

    public int getS_T_id() {
        return S_T_id;
    }

    public void setS_T_id(int s_T_id) {
        S_T_id = s_T_id;
    }





}
