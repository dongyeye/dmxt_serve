package fzu.edu.dmxt.service;

import java.util.List;

import fzu.edu.dmxt.pojo.Category;

public interface CategoryService {

	List<Category> list();

}
