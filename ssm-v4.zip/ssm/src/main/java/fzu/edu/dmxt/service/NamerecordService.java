package fzu.edu.dmxt.service;

public interface NamerecordService {
}
