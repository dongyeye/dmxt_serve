package fzu.edu.dmxt.service;

import fzu.edu.dmxt.pojo.Permission;

public interface PermissionService {
    Permission get(int per_id);
}
