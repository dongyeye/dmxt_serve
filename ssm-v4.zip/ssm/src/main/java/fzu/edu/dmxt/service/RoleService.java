package fzu.edu.dmxt.service;

import fzu.edu.dmxt.pojo.Role;

public interface RoleService {
    Role get(int id);
}
