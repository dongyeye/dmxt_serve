package fzu.edu.dmxt.service.impl;

import fzu.edu.dmxt.service.NamerecordService;
import org.springframework.stereotype.Service;

@Service
public class NamerecordServiceImpl implements NamerecordService{
}
